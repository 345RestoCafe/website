<script>
export default {
  name: "ReviewsCarouselComponent"
}
</script>

<template>

</template>

<style scoped>

</style>