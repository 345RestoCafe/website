<script>
import UnderDevelopment from "@/public/components/UnderDevelopmentView.vue";

export default {
  name: "ContactUsView",
  components: {UnderDevelopment}
}
</script>

<template>
  <UnderDevelopment/>
</template>

<style scoped>

</style>