<script>
import UnderDevelopment from "@/public/components/UnderDevelopmentView.vue";

export default {
  name: "AboutUsView",
  components: {UnderDevelopment}
}
</script>

<template>
  <UnderDevelopment/>
</template>

<style scoped>

</style>